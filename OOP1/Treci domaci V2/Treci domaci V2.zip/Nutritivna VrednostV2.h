#pragma once
#ifndef _nutritivna_h_
#define _nutritivna_h_
#include<iostream>
using namespace std;
class Nutritivna {

	double ugljeni_hidrati;
	double masti;
	double proteini;
public:
	Nutritivna(double uh, double m, double p) : ugljeni_hidrati(uh), masti(m), proteini(p) {}
	
	double dohv_uh() const { return ugljeni_hidrati; }
	double dohv_ma() const { return masti; }
	double dohv_pr() const { return proteini; }

	friend Nutritivna operator+(const Nutritivna& n1, const Nutritivna& n2) {
		return Nutritivna(n1.ugljeni_hidrati + n2.ugljeni_hidrati, n1.masti + n2.masti, n1.proteini + n2.proteini);
	}
	friend ostream& operator<<(ostream& os, const Nutritivna& n) {
		os << "[uh: " << n.ugljeni_hidrati << ", ma: " << n.masti << ", pr: " << n.proteini << "]";
		return os;
	}

	double br_kalorij() const { return (this->masti * 9 + this->proteini * 4 + this->ugljeni_hidrati * 4); }
	


};
#endif // !_nutritivna_h_

