#pragma once
#ifndef _namirnica_h_
#define _namirnica_h_
#include <string>
#include "Nutritivna VrednostV2.h"

class Namirnica {
	string naziv;
	bool posna;
	Nutritivna nv100gr;

public:
	Namirnica(string naziv, const Nutritivna& n, bool posna) : naziv(naziv), nv100gr(n), posna(posna) {}

	friend bool operator==(const Namirnica& n1, const Namirnica& n2) {
		if (n1.naziv == n2.naziv) return true;
		else return false;
	}

	string dohv_naziv() const { return naziv; }
	Nutritivna dohv_nv() const { return nv100gr; }
	bool dohv_posna() const { return posna; }

	friend ostream& operator<<(ostream& os, const Namirnica& n) {
		os << n.naziv << "-" << n.nv100gr;
		return os;
	}

	
};

#endif // !

