#pragma once
#ifndef _sastojak_h_
#define _sastojak_h_
#include "NamirnicaV2.h"


class Sastojak {
	Namirnica namirnica;
	double kolicina;
public:
	Sastojak(const Namirnica& n, double kolicina): namirnica(n), kolicina(kolicina){}

	Namirnica dohv_nam() const { return namirnica; }
	double dohv_kolicinu() const { return kolicina; }

	Nutritivna dohv_nv_sastojka() const { return namirnica.dohv_nv(); }
	double dohv_kal_sastojka() const { return namirnica.dohv_nv().br_kalorij(); }

	friend ostream& operator<<(ostream& os, const Sastojak& s) {
		os << "[" << s.dohv_kal_sastojka() << " kcal] " << s.kolicina << "g x " << s.namirnica;
		return os;
	}
};
#endif // !_sastojak_h_
