#include "SastojakV2.h"
#include "ListaV2.h"
void main(){
	try {
		Nutritivna nv1(15, 40, 10);
		Nutritivna nv2(20, 50, 30);

		Namirnica nam1("Jaje", nv1, true);
		Namirnica nam2("Pavlaka", nv2, false);

		cout << (nv1 + nv2) << endl;

		if (nam1 == nam2) {
			cout << "Namirnice su iste" << endl;
			cout << nam1 << endl;
		}
		else cout << "Namirnice nisu iste" << endl;
		Sastojak s1(nam1, 100);
		Sastojak s2(nam2, 200);



		Lista<Sastojak*> lista;
		lista.dodaj(&s1);
		lista.dodaj(&s2);

	}
	catch (exception e) {
		cout << e.what() << endl;
	}
}