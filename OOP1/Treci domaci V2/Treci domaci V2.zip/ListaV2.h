#pragma once
#ifndef _lista_h_
#define _lista_h_
#include <iostream>
#include "GreskaV2.h"
using namespace std;

template<typename T>
class Lista {

	struct Elem {
		T info;
		Elem* next;
		Elem(const T& t) {
			info = t;
			next = nullptr;
		}
	};
	Elem* head;
	Elem* tail;
	mutable Elem* curr;
	void kopiraj(const Lista& l);
	void premesti(Lista& l) {
		head = l.head;
		tail = l.tail;
		curr = l.curr;

		l.head = l.tail = l.curr = nullptr;
	}
	void brisi();
public:
	Lista() {
		head = tail = curr = nullptr;
	}
	Lista(const Lista& l) = delete;
	Lista(Lista&& l) { premesti(l); }
	~Lista() { brisi(); }
	Lista& operator=(const Lista& l) = delete;
		
	Lista& operator=(Lista&& l) {
		if (this != &l) {
			brisi();
			premesti(l);
		}
		return *this;
	}

	Lista& dodaj(const T& t) {
		Elem* node = new Elem(t);
		if (head == nullptr) head = node;
		else tail->next = node;
		tail = node;
		return *this;
	}
	

	void postaviNaPrvi() {
		curr = head;

	}
	const void postaviNaPrvi() const {
		curr = head;

	}
	void predjiNaSledeci() {
		if (curr) curr = curr->next;
	}
	const void predjiNaSledeci() const {
		if (curr) curr = curr->next;

	}
	bool postoji_tekuci() const { return curr != nullptr; }

	T& dohv_tekuci() {
		if (!postoji_tekuci()) throw GNemaTekuci();
		return this->curr->info;

	}
	const T& dohv_tekuci() const {
		if (!postoji_tekuci()) throw GNemaTekuci();
		return this->curr->info;

	}

};
template<typename T>
void Lista<T>::brisi() {
	while (head) {
		Elem* tmp = head;
		head = head->next;
		delete tmp;
	}
	tail = curr = nullptr;
}

#endif // !_lista_h_
