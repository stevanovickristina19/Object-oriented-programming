#pragma once
#ifndef _greska_h_
#define _greska_h_

#include <iostream>
using namespace std;
#include <exception>

class GNemaTekuci :public exception {
public:
	GNemaTekuci() : exception("Greska: Ne postoji tekuci element.") {}

};
#endif // !_greska_h_