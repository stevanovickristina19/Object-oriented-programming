#pragma once
#ifndef _greska_h_
#define _greska_h_
#include <exception>
using namespace std;
class GZvezdice : public exception {
public:
	GZvezdice() :exception("Greska: Nepravilan unos zvezdica.") {}

};
class GPogresanDatum : public exception {
public:
	GPogresanDatum() :exception("Greska: Pogresno unet datum.") {}

};
class GPogresanSmestaj: public exception {
public:
	GPogresanSmestaj() :exception("Greska: Smestaj nije vezan sa destinacijom iz aranzmana.") {}

};
class GPogresanPrevoz : public exception {
public:
	GPogresanPrevoz() :exception("Greska: Prevoz nije vezan sa destinacijom iz aranzmana.") {}

};
class GNisuDodeljeni : public exception {
public:
	GNisuDodeljeni() :exception("Greska: Smestaj ili prevoz nisu dodeljeni aranzmanu.") {}

};
#endif // !_greska_h_

