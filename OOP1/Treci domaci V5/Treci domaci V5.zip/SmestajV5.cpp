#include "SmestajV5.h"

ostream& operator<<(ostream& os, const Smestaj& s)
{
    string zvezdice_ispis;
    switch (s.br_zvezdica) {
    case 1: {
        zvezdice_ispis = "*";
        break;
    }
    case 2: {
        zvezdice_ispis = "**";
        break;
    }
    case 3: {
        zvezdice_ispis = "***";
        break;
    }
    case 4: {
        zvezdice_ispis = "****";
        break;
    }
    case 5: {
        zvezdice_ispis = "*****";
        break;
    }
    }
    os << s.tip << " " << s.naziv << " " << zvezdice_ispis;
    return os;
}
