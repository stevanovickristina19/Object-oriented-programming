#include "DestinacijaV5.h"
#include "SmestajV5.h"
#include "DatumV5.h"
#include "PrevozV5.h"
#include "AranzmanV5.h"
void main() {
	try {
		Destinacija d1("Sutomore", "Pogled na more.");
		Destinacija d2("Krusevac", "Vila");
		d2.oceni(3);
		d1.oceni(4);
		d1.oceni(5);
		d1.oceni(5);
		d1.oceni(5);
		d1.oceni(6);
		cout << d1 << endl;

		Smestaj s(d1, "HOTEL", "Manojlovic", 5, 100);

		cout << s << endl;

		Datum dat1(2, 9, 2001);
		Datum dat2(3, 5, 2001);

		cout << dat1 << endl;
		cout << dat2 << endl;

		cout << "Razlika izmedju datuma je " << (dat1 - dat2) << endl;

		Aranzman a(d1, dat2, dat1);

		Prevoz p1(d1, 300);
		a.dodeli_prevoz(p1);
		a.dodeli_smestaj(s);

		cout << a;
	}
	catch (exception e) {
		cout << e.what() << endl;
	}
	cout << endl << "Kraj programa..." << endl << endl;
}