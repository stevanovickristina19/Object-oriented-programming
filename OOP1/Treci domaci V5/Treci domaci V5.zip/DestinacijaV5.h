#pragma once
#ifndef _destinacija_h_
#define _destinacija_h_
#include <iostream>
using namespace std;
class Destinacija {
	string naziv;
	string opis;
	int br_ocena;
	double prosecna_ocena;
public:
	Destinacija(string naziv, string opis) :naziv(naziv), opis(opis) {
		br_ocena = 0;
		prosecna_ocena = 0;
	}
	void oceni(int ocena) {
		if (ocena > 0 && ocena < 6) {
			double uk_ocena = prosecna_ocena * br_ocena + ocena;
			br_ocena++;
			prosecna_ocena = uk_ocena / br_ocena;
		}
	}
	string dohv_naziv() const { return naziv; }
	string dohv_opis() const { return opis; }
	double dohv_po() const { return prosecna_ocena; }

	friend bool operator>(const Destinacija& d1, const Destinacija& d2) {
		if (d1.prosecna_ocena > d2.prosecna_ocena) return true;
		else return false;
	}
	friend ostream& operator<<(ostream& os, const Destinacija& d) {
		os << "[" << d.prosecna_ocena << "]" << " " << d.naziv << " (" << d.opis << ")";
		return os;
	}


};
#endif // !_destinacija_h_
