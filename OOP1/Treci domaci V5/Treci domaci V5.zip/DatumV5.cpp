#include "DatumV5.h"

Datum::Datum(int d, int m, int g)
{
	if (d <= 0 || d > 31) throw GPogresanDatum();
	if (m <= 0 || m > 12) throw GPogresanDatum();
	this->godina = g;
	this->mesec = m;
	
	switch (mesec) {
	case 4:case 6:case 9:case 11:{
		if (d == 31) throw GPogresanDatum();
		this->dan = d;
		break;
	}
	
	case 2: {
		if (godina % 400 == 0 || godina % 4 == 0 && godina % 100 != 0) {
			if (d >= 30) throw GPogresanDatum();
			this->dan = d;
		}
		else {
			if (d >= 29) throw GPogresanDatum();
			this->dan = d;
		}
		break;
	}
	default: {
		dan = d;
		break;
	}
	}

}

int operator-(const Datum& d1, const Datum& d2)
{
	int uk_broj1 = 0;
	int uk_broj2 = 0;
	int broj_prestupnih1;
	int broj_prestupnih2;
	broj_prestupnih1 = d1.godina / 4;
	broj_prestupnih2 = d2.godina / 4;
	for (int i = 1; i < d1.mesec; i++) {
		switch (i)
		{	
		case 1:case 3:case 5:case 7: case 8:case 10:case 12: {
			uk_broj1 += 31;
			break;
		}
		case 4:case 6: case 9:case 11: {
			uk_broj1 += 30;
			break;
		}
		case 2: {
			if (d1.godina % 400 == 0 || d1.godina % 4 == 0 && d1.godina % 100 != 0) {
				uk_broj1 += 29;
			}
			else uk_broj1 += 28;
			break;
		}

		}
	}
	uk_broj1 = uk_broj1 + d1.dan + (broj_prestupnih1 * 366 + (d1.godina - broj_prestupnih1) * 365);
	
	for (int i = 1; i < d2.mesec; i++) {
		switch (i)
		{
		case 1:case 3:case 5:case 7: case 8:case 10:case 12: {
			uk_broj2 += 31;
			break;
		}
		case 4:case 6: case 9:case 11: {
			uk_broj2 += 30;
			break;
		}
		case 2: {
			if (d2.godina % 400 == 0 || d2.godina % 4 == 0 && d2.godina % 100 != 0) {
				uk_broj2 += 29;
			}
			else uk_broj2 += 28;
			break;
		}

		}
	}
	uk_broj2 = uk_broj2 + d2.dan + (broj_prestupnih2 * 366 + (d2.godina - broj_prestupnih2) * 365);

	return abs(uk_broj1 - uk_broj2);
}
