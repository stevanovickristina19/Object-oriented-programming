#pragma once
#ifndef _smestaj_h_
#define _smestaj_h_
#include "DestinacijaV5.h"
#include "GreskaV5.h"
class Smestaj {
	Destinacija destinacija;
	string tip;
	string naziv;
	int br_zvezdica;
	double cena_po_danu;
public:
	
	Smestaj(const Destinacija& d, string tip, string naziv, int zvezdice, double cena) : destinacija(d){
		if (zvezdice < 0 || zvezdice > 5) throw GZvezdice();
		this->br_zvezdica = zvezdice;
		this->cena_po_danu = cena;
		this->naziv = naziv;
		this->tip = tip;
	}
	const Destinacija& dohv_destinaciju() const { return destinacija; }
	string dohv_tip() const { return tip; }
	string dohv_naziv() const { return naziv; }
	int dohv_zvezdice() const { return br_zvezdica; }
	double dohv_cenu() const { return cena_po_danu; }

	friend ostream& operator<<(ostream& os, const Smestaj& s);
	

};
#endif // !_smestaj_h_

