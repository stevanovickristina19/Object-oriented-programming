#include "AranzmanV5.h"

void Aranzman::dodeli_smestaj(Smestaj& s) {
	if (s.dohv_destinaciju().dohv_naziv() != destinacija.dohv_naziv() &&
		s.dohv_destinaciju().dohv_opis() != destinacija.dohv_opis() &&
		s.dohv_destinaciju().dohv_po() != destinacija.dohv_po()) throw GPogresanSmestaj();
	smestaj = &s;
}

void Aranzman::dodeli_prevoz(Prevoz& p) {
	if (p.dohv_dest().dohv_naziv() != destinacija.dohv_naziv() &&
		p.dohv_dest().dohv_opis() != destinacija.dohv_opis() &&
		p.dohv_dest().dohv_po() != destinacija.dohv_po()) throw GPogresanPrevoz();

	prevoz = &p;
}