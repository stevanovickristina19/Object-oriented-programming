#pragma once
#ifndef _aranzman_h_
#define _aranzman_h_
#include "DatumV5.h"
#include "DestinacijaV5.h"
#include "SmestajV5.h"
#include "PrevozV5.h"
class Aranzman {
	Destinacija destinacija;
	Datum pocetak;
	Datum kraj;
	Smestaj* smestaj;
	Prevoz* prevoz;
public:
	Aranzman(const Destinacija& d, const Datum& d1, const Datum& d2) : destinacija(d), pocetak(d1), kraj(d2) {
		smestaj = nullptr;
		prevoz = nullptr;
	}

	void dodeli_smestaj(Smestaj& s);
	void dodeli_prevoz(Prevoz& p);
	const Destinacija& dohv_destinaciju() const { return destinacija; }
	const Datum& dohv_pocetak() const { return pocetak; }
	const Datum& dohv_kraj() const { return kraj; }

	int dohv_trajanje() const {
		return (pocetak - kraj);
	}
	double dohv_uk_cenu() const {
		if (smestaj == nullptr || prevoz == nullptr) throw GNisuDodeljeni();
		return (prevoz->dohv_cenuKarte() * 2 + this->dohv_trajanje() * smestaj->dohv_cenu());
	}
	friend ostream& operator<<(ostream& os, const Aranzman& a) {
		os << "Aranzman: " << endl << a.destinacija << endl << *(a.smestaj) << endl << a.dohv_uk_cenu() << endl;
		return os;
	}
};
#endif // !_aranzman_h_

