#pragma once
#ifndef _prevoz_h_
#define _prevoz_h_
#include "DestinacijaV5.h"
class Prevoz {
	Destinacija destinacija;
	double cena_karte;
public:
	Prevoz(const Destinacija& d,double cena) :destinacija(d), cena_karte(cena) {}

	const Destinacija& dohv_dest() const { return destinacija; }
	double dohv_cenuKarte() const { return cena_karte; }

};
#endif // !_prevoz_h_
